-- :name all_users :many
SELECT * FROM users;
