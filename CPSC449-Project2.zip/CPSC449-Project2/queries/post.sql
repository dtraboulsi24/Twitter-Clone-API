-- :name post :insert
INSERT INTO posts(username, text, post_time) VALUES(:username, :text, :post_time);
